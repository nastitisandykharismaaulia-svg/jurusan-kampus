# Website Tes Penentuan Jurusan Kuliah (100 Soal)

Proyek website statis yang dibangun menggunakan **4 bahasa/format** (`HTML5`, `CSS3`, `JavaScript ES6`, dan `JSON`) dan siap di-deploy ke **GitHub Pages**.

## Isi Paket ZIP
- `index.html`: Struktur kerangka halaman utama.
- `style.css`: Tampilan aesthetic dengan palet warna tenang (*sage green* & krem lembut).
- `app.js`: Logika navigasi kuis, perhitungan 5 poin per soal (maksimal 500 poin), dan tampilan hasil rekomendasi jurusan.
- `data.json`: Database lengkap berisi **100 pertanyaan**, informasi 6 rumpun jurusan, rekomendasi 3 kampus terbaik, dan syarat pendaftarannya.

## Cara Upload ke GitHub Pages
1. Ekstrak file ZIP ini ke dalam satu folder.
2. Buat repository baru di GitHub (misalnya `tes-jurusan-kuliah`).
3. Unggah semua file (`index.html`, `style.css`, `app.js`, `data.json`, `README.md`) ke folder utama repository.
4. Masuk ke menu **Settings > Pages**, pilih **Branch: main**, lalu klik **Save**.
