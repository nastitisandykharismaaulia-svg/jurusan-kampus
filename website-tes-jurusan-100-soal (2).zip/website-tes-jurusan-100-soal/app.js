let quizData = null;
let currentQuestionIndex = 0;
let userAnswers = [];
const POINTS_PER_QUESTION = 5;

const welcomeScreen = document.getElementById('welcome-screen');
const quizScreen = document.getElementById('quiz-screen');
const resultScreen = document.getElementById('result-screen');

const startBtn = document.getElementById('start-btn');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const restartBtn = document.getElementById('restart-btn');

const questionCounter = document.getElementById('question-counter');
const scoreCounter = document.getElementById('score-counter');
const progressFill = document.getElementById('progress-fill');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');

async function loadQuizData() {
    try {
        const response = await fetch('data.json');
        if (!response.ok) throw new Error('Gagal memuat data.json');
        quizData = await response.json();
        userAnswers = new Array(quizData.questions.length).fill(null);
    } catch (error) {
        alert('Pastikan website dijalankan melalui server lokal (Live Server) atau GitHub Pages agar file data.json dapat terbaca.');
        console.error(error);
    }
}

startBtn.addEventListener('click', () => {
    if (!quizData) return;
    welcomeScreen.classList.add('hidden');
    quizScreen.classList.remove('hidden');
    renderQuestion();
});

function renderQuestion() {
    const totalQuestions = quizData.questions.length;
    const currentQ = quizData.questions[currentQuestionIndex];
    const answeredCount = userAnswers.filter(ans => ans !== null).length;

    questionCounter.textContent = `Soal ${currentQuestionIndex + 1} dari ${totalQuestions}`;
    scoreCounter.textContent = `Poin Terkumpul: ${answeredCount * POINTS_PER_QUESTION} / ${totalQuestions * POINTS_PER_QUESTION}`;
    const progressPercent = ((currentQuestionIndex + 1) / totalQuestions) * 100;
    progressFill.style.width = `${progressPercent}%`;

    questionText.textContent = `${currentQuestionIndex + 1}. ${currentQ.question}`;

    optionsContainer.innerHTML = '';
    currentQ.options.forEach((opt) => {
        const button = document.createElement('button');
        button.className = 'option-btn';
        if (userAnswers[currentQuestionIndex] === opt.category) {
            button.classList.add('selected');
        }
        button.textContent = opt.text;
        button.addEventListener('click', () => selectOption(opt.category));
        optionsContainer.appendChild(button);
    });

    prevBtn.disabled = currentQuestionIndex === 0;
    nextBtn.disabled = userAnswers[currentQuestionIndex] === null;
    nextBtn.textContent = currentQuestionIndex === totalQuestions - 1 ? 'Lihat Hasil Jurusan ✓' : 'Selanjutnya →';
}

function selectOption(category) {
    userAnswers[currentQuestionIndex] = category;
    renderQuestion();
}

prevBtn.addEventListener('click', () => {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        renderQuestion();
    }
});

nextBtn.addEventListener('click', () => {
    if (currentQuestionIndex < quizData.questions.length - 1) {
        currentQuestionIndex++;
        renderQuestion();
    } else {
        calculateAndShowResult();
    }
});

function calculateAndShowResult() {
    const categoryScores = { IT: 0, MED: 0, BIZ: 0, LAW: 0, ART: 0, ENG: 0 };
    let totalPoints = 0;

    userAnswers.forEach(category => {
        if (category) {
            categoryScores[category] = (categoryScores[category] || 0) + POINTS_PER_QUESTION;
            totalPoints += POINTS_PER_QUESTION;
        }
    });

    let topCategory = Object.keys(categoryScores)[0];
    for (const cat in categoryScores) {
        if (categoryScores[cat] > categoryScores[topCategory]) {
            topCategory = cat;
        }
    }

    const resultInfo = quizData.majors[topCategory];

    document.getElementById('final-score').textContent = totalPoints;
    document.getElementById('major-title').textContent = resultInfo.title;
    document.getElementById('major-desc').textContent = resultInfo.description;

    const breakdownContainer = document.getElementById('score-breakdown');
    breakdownContainer.innerHTML = '';
    Object.entries(categoryScores)
        .sort((a, b) => b[1] - a[1])
        .forEach(([cat, score]) => {
            const pill = document.createElement('span');
            pill.className = 'score-pill';
            pill.textContent = `${quizData.majors[cat].shortName}: ${score} poin`;
            breakdownContainer.appendChild(pill);
        });

    const campusesList = document.getElementById('campuses-list');
    campusesList.innerHTML = '';
    resultInfo.campuses.forEach(campus => {
        const div = document.createElement('div');
        div.className = 'campus-card';
        div.innerHTML = `<h4>${campus.name}</h4><p>${campus.location} • ${campus.accreditation}</p>`;
        campusesList.appendChild(div);
    });

    const admissionList = document.getElementById('admission-info');
    admissionList.innerHTML = '';
    resultInfo.admission.forEach(info => {
        const li = document.createElement('li');
        li.textContent = info;
        admissionList.appendChild(li);
    });

    quizScreen.classList.add('hidden');
    resultScreen.classList.remove('hidden');
}

restartBtn.addEventListener('click', () => {
    currentQuestionIndex = 0;
    userAnswers = new Array(quizData.questions.length).fill(null);
    resultScreen.classList.add('hidden');
    welcomeScreen.classList.remove('hidden');
});

loadQuizData();
